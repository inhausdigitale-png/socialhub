﻿# Social Hub Studio - Vercel Upload

Upload this folder/zip to Vercel as a static web app.

## Vercel Settings

- Framework preset: Other
- Build command: leave empty
- Output directory: leave empty
- Install command: leave default or empty

## Entry File

`index.html`

## Notes

This is the latest webapp prototype preview with Content Studio, Idea Feeds, approvals, scheduling, analytics, inbox, billing, connections, settings, and owner/white-label dashboard.
