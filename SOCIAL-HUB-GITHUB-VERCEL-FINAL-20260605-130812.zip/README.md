# Social Hub Studio

This folder is ready to upload to GitHub and deploy on Vercel.

## What Is Included

- Latest Social Hub Studio web app UI
- Content Studio
- Social account selection
- Approvals
- Calendar scheduler
- Inbox
- Monitor
- Analytics
- Reports
- Billing
- Settings
- Owner white-label dashboard
- Idea Feeds AI workflow prototype

## Deploy On Vercel

1. Upload this folder to GitHub.
2. Open Vercel.
3. Click **Add New Project**.
4. Import the GitHub repository.
5. Use these settings:

- Framework Preset: `Other`
- Build Command: leave empty
- Output Directory: leave empty
- Install Command: default

## Local Preview

```bash
npm install
npm run preview
```

Then open the local URL shown in the terminal.

## Important

This is a front-end deployable prototype. Real publishing, AI generation, payments, analytics fetching, and social login need live API credentials connected in the backend before production launch.
